package org.sesac.spring_game.exception;

public class JudgeNotFoundException extends Exception {

	public JudgeNotFoundException(String string) {
		super(string);
	}
	
}
